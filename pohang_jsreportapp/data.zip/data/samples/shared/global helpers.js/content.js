function nowLocalStr () {
  return new Date().toLocaleDateString()
}
